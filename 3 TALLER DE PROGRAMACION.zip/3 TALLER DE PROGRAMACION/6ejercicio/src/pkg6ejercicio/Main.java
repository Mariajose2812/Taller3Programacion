/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg6ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Scanner teclado = new Scanner(System.in);
    int nota;
    int edad;
    String sexo;

   
    System.out.print("EDAD: ");
    edad = teclado.nextInt();
    System.out.print("NOTA: ");
    nota = teclado.nextInt(); teclado.nextLine();
    System.out.print("SEXO M o F): ");
    sexo = teclado.nextLine();
    

    if (!sexo.toUpperCase().equals("M") && !sexo.toUpperCase().equals("F")) {
      System.out.println("El valor de sexo introducido es incorrecto.\n"  + "por favor, reenvíe el formulario.");
    } else if ((nota >= 5) && (edad >= 18) && (sexo.toUpperCase().equals("M"))) {
      System.out.println("POSIBLE");
    }else if ((nota >= 5) && (edad >= 18) && (sexo.toUpperCase().equals("F"))) {
       System.out.println("ACEPTADA");
    }else {
        System.out.println("NO ACEPTADA");
    }
    }
    
}
