/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg13ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
     Scanner teclado = new Scanner(System.in);

       
        System.out.print("Ingresa el resultado obtenido al lanzar el dado: ");
        int resultado = teclado.nextInt();

        if (resultado < 1 || resultado > 6) {
            System.out.println("ERROR: número incorrecto");
            return;
        }

    
        String numeroOpuesto = "";
        switch (resultado) {
            case 1:
                numeroOpuesto = "Seis";
                break;
            case 2:
                numeroOpuesto = "Cinco";
                break;
            case 3:
                numeroOpuesto = "Cuatro";
                break;
            case 4:
                numeroOpuesto = "Tres";
                break;
            case 5:
                numeroOpuesto = "Dos";
                break;
            case 6:
                numeroOpuesto = "Uno";
                break;
        }

        System.out.println("El número opuesto es: " + numeroOpuesto);
    }
}
    
    

