/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg11ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Scanner teclado = new Scanner(System.in);
    
    int numeroAlumnos;

   
    System.out.print("ESCRIBE LA CANTIDAD DE ALUMNOS:");
    numeroAlumnos = teclado.nextInt();

    
    if (numeroAlumnos >= 100) {
      System.out.println("PAGO QUE SE LE DEBE HACER A LA AGENCIA " + numeroAlumnos*65 + " "
          + " EUROS Y CADA ALUMNO DEBE PAGAR 65 EUROS");
      
    } else if (numeroAlumnos <100 && numeroAlumnos >= 50) {
      System.out.println("PAGO QUE SE LE DEBE HACER A LA AGENCIA " + numeroAlumnos*70 + " "
          + " EUROS Y CADA ALUMNO DEBE PAGAR 70 EUROS");
      
    } else if (numeroAlumnos < 50 && numeroAlumnos >= 30) {
      System.out.println("PAGO QUE SE LE DEBE HACER A LA AGENCIA " + numeroAlumnos*95 + " "
          + " EUROS Y CADA ALUMNO DEBE PAGAR 95 EUROS");
    } else {
      System.out.println("EL COSTO DEL AUTOBUS ES DE 4000 EUROS Y CADA ALUMNO"
          + "DEBE PAGAR  " + (4000/numeroAlumnos) + " EUROS.");
    }
    }
    
}
