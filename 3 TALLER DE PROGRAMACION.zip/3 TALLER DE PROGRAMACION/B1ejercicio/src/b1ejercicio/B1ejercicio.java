/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b1ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Random;
import java.util.Scanner;
public class B1ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Random random = new Random();
        int numeroAdivinar = random.nextInt(100) + 1; 
        int intentos = 10;

        Scanner teclado = new Scanner(System.in);

        while (intentos > 0) {
            System.out.print("ADIVINA EL NUMERO (te quedan " + intentos + " intentos): ");
            int numeroIntroducido = teclado.nextInt();

            if (numeroIntroducido == numeroAdivinar) {
                System.out.println("¡SUPER! Has adivinado el numero en " + (11 - intentos) + " intentos.");
                return;
            } else if (numeroIntroducido < numeroAdivinar) {
                System.out.println("EL NUMERO ES MAYOR QUE  " + numeroIntroducido);
            } else {
                System.out.println("EL NUMERO ES MENOR QUE  " + numeroIntroducido);
            }

            intentos--;
        }

        System.out.println("¡LO SIENTO! YA NO TIENES MAS INTENTOS . EL NUMERO A ADIVINAR ERA " + numeroAdivinar);
    }

}
