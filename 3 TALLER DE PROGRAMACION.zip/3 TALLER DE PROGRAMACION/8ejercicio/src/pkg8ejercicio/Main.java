/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg8ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line argument
     */
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
      
        System.out.println("ESCRIBA EL TAMAÑO DEL LADO 1: ");
        double lado1 = teclado.nextDouble();
        System.out.println("ESCRIBA EL TAMAÑO DEL LADO 2: ");
        double lado2 = teclado.nextDouble();
        System.out.println("ESCRIBA EL TAMAÑO DEL LADO 3: ");
        double lado3 = teclado.nextDouble();
        
       
        if (lado1 == lado2 && lado2 == lado3) {
            System.out.println("EL TRIANGULO ES EQUILATERO.");
        } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
            System.out.println("EL TRIANGULO ES ISOCELES.");
        } else {
            System.out.println("EL TRIANGULO ES ESCALENO.");
        }
        
        
        double hipotenusa;
        if (lado1 > lado2 && lado1 > lado3) {
            hipotenusa = lado1;
            if (hipotenusa * hipotenusa == lado2 * lado2 + lado3 * lado3) {
                System.out.println("EL TRIANGULO ES RECTANGULO.");
            }
        } else if (lado2 > lado1 && lado2 > lado3) {
            hipotenusa = lado2;
            if (hipotenusa * hipotenusa == lado1 * lado1 + lado3 * lado3) {
                System.out.println("EL TRIANGULO ES RECTANGULO.");
            }
        } else if (lado3 > lado1 && lado3 > lado2) {
            hipotenusa = lado3;
            if (hipotenusa * hipotenusa == lado1 * lado1 + lado2 * lado2) {
                System.out.println("EL TRIANGULO ES RECTANGULO.");
            }
    }
    }
}
    

