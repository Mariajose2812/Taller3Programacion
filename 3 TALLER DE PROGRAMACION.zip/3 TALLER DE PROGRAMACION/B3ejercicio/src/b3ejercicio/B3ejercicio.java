/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b3ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B3ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
    Scanner teclado = new Scanner(System.in);
    
    
        System.out.println("ESCRIBA UNA PALABRA: ");
        
        while(teclado.hasNext()){
            String letra = teclado.next().toLowerCase();
            
            if (letra.equals(" ")) {
                break;
            } else if (letra.equals("a") || letra.equals("e") || letra.equals("i") || letra.equals("o") || letra.equals("u")) {
                System.out.println("VOCAL");
            } else {
                System.out.println("NO VOCAL");
            }
        }
    }
}
    
    

