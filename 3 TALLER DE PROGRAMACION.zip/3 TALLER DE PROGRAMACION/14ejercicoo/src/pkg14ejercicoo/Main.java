/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg14ejercicoo;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        Scanner teclado = new Scanner(System.in);

        
        System.out.print("Escriba  el día de la semana (del 1 al 7): ");
        int dia = teclado.nextInt();

        
        String diaCorrespondiente = "";
        switch (dia) {
            case 1:
                diaCorrespondiente = "Lunes";
                break;
            case 2:
                diaCorrespondiente = "Martes";
                break;
            case 3:
                diaCorrespondiente = "Miércoles";
                break;
            case 4:
                diaCorrespondiente = "Jueves";
                break;
            case 5:
                diaCorrespondiente = "Viernes";
                break;
            case 6:
                diaCorrespondiente = "Sábado";
                break;
            case 7:
                diaCorrespondiente = "Domingo";
                break;
            default:
                System.out.println("ERROR");
                return;
        }

     
        System.out.println("El dia que corresponde es: " + diaCorrespondiente);
    }
}
    
    

