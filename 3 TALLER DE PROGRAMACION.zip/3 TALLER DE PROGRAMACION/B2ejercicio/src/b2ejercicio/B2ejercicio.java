/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b2ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B2ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
    Scanner teclado = new Scanner(System.in);
    
    int numero = 0;
    int contador;
    int mayor = 0;
    int igual = 0;
    int menor = 0;

   
    System.out.print("ESCRIBE LA CANTIDAD DE NUMEROS QUE QUIERES INTRODUCIR : ");
    contador = teclado.nextInt();
    do {
      if (contador <= 0) {
        System.out.println("El número introducido debe ser un entero positivo. Por favor, introduce un nuevo valor.");
        contador = teclado.nextInt();
      }
    } while (contador <= 0);
    while (contador > 0){
      System.out.println("ESCRIBE UN NUMERO: ");
      numero = teclado.nextInt();
      contador = contador-1;
      if (numero > 0){
        mayor++;
      } else if (numero < 0){
        menor++;
      } else {
        igual++;
      }
    }    
    System.out.println("HAS ESCRITO TODOS LOS VALORES:\n" + mayor + " SON MAYORES A 0\n" + menor + " SON MENORES A 0\n" + igual + " SON IGUALES A 0.");
  }
    }
    

