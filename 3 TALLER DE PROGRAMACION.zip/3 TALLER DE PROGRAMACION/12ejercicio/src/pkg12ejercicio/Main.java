/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg12ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner(System.in);
    
    int duracion;
    String dia;
    String horario;
    double precio;
    double impuesto;
   
    System.out.print("CUANTO DURO LA LLAMADA(MINUTOS): ");
    duracion = teclado.nextInt();
    System.out.print("DIA DE LA SEMANA: ");
    dia = teclado.next(); teclado.nextLine();
    
   
    if (duracion > 10){
        precio = 3;
    } else if (duracion > 8){
        precio = 2.5;
    } else if (duracion > 5){
        precio = 1.80;
    } else {
        precio = 1;
    }   
    
   
    if (!dia.toUpperCase().equals("DOMINGO")) {
      System.out.print(" LA LLAMADA SE REALIZO EN LA MAÑANA O TARDE:");
      horario = teclado.nextLine();
      if (horario.toUpperCase().equals("MAÑANA")) {
        impuesto = precio * 0.15;
      } else if (horario.toUpperCase().equals("TARDE")) {
        impuesto = precio * 0.10;
      
      } else {
        impuesto = 0; 
      }
    } else {
      impuesto = precio * 0.03;
    }
    
    
    if (impuesto == 0) {
      System.out.println("El horario introducido es incorrecto, reinicia el programa "
          + "e introduce los valores correctos.");
    } else {
      System.out.println("El precio total de la llamada es de " + (precio + impuesto) 
          + " siendo el precio base de " + precio + " y el impuesto a pagar " + impuesto);
    }
    }
    
}
