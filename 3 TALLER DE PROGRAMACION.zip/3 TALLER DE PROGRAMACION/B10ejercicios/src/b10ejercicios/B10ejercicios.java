/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b10ejercicios;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B10ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           
    Scanner teclado = new Scanner(System.in);
    
    System.out.println("Escribe el numero de niveles que tendra la piramide: ");
    int numeroNiveles = teclado.nextInt();
    
    int numeroPosiciones = numeroNiveles * 2 -1;
    int posInicial = numeroNiveles;
    int posFinal = numeroNiveles;
    
    
    for (int i = 0; i < numeroNiveles; i++) {
      int contador = 1;
      String resultado = "";
      
      for (int j=0; j <= numeroPosiciones; j++) {
        if ((j < posInicial) || (j > posFinal)) {
          resultado += " ";
        } else {
          if (j < numeroNiveles) {
            resultado += contador;
            contador++;
          } else {
            resultado += contador;
            contador--;
          }
        }    
      }
      System.out.println(resultado);
      posFinal++;
      posInicial--;
    }
  }
}
    
    

