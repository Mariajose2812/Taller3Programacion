/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b6ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B6ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Scanner teclado = new Scanner(System.in);
    
    double base;
    int exponente;
    double resultado;
   
    System.out.print("Escriba la base de la potencia: ");
    base = teclado.nextDouble();
    do {
      System.out.print("ESCRIBA EL EXPONENTE (entero positivo) DE LA POTENCIA: ");
      exponente = teclado.nextInt();
      if (exponente <= 0) {
        System.out.println("ERROR, el exponente debe ser un entero positivo.");
      }
    } while (exponente <= 0);
    resultado = base;
   
    
    for (int i=1; i<exponente;i++){
      resultado = (resultado*base);
    }
    
    System.out.println("EL RESULTADO DE LA POTENCIA ES: " + resultado);
  }
}
        
    
