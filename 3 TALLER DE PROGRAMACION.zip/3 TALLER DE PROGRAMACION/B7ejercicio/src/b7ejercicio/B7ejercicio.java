/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b7ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B7ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
    Scanner teclado = new Scanner(System.in);
    
      
    double cuota;
    int mensualidades;
    double totalPagado = 0;

    System.out.print("Escriba la primera cuota a pagar: ");
    cuota = teclado.nextDouble();
    System.out.print("Escribal numero de meses de financiación: ");
    mensualidades = teclado.nextInt();
    
    for (int i=1; i <= mensualidades; i++){
      System.out.println("Cuota "+ i +": "+ cuota);
      totalPagado = totalPagado + cuota;
      cuota = cuota*2;
    } 

    System.out.println("Total pagado por el producto: " + (int)totalPagado);
    }
    
}
