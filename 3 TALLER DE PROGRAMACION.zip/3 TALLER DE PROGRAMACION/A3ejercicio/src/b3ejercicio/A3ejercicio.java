/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b3ejercicio;

/**
 *
 * @author Maria jose
 */

import java.util.Scanner;
public class A3ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      int[][] numeros = new int[4][5];
        Scanner sc = new Scanner(System.in);

       
        System.out.println("ESCRIBE 20 NUMEROS:");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                numeros[i][j] = sc.nextInt();
            }
        }

      
        int sumaTotal = 0;
        for (int i = 0; i < 4; i++) {
            int sumaFila = 0;
            for (int j = 0; j < 5; j++) {
                System.out.print(numeros[i][j] + "\t");
                sumaFila += numeros[i][j];
                sumaTotal += numeros[i][j];
            }
            System.out.println("| " + sumaFila);
        }
        for (int j = 0; j < 5; j++) {
            System.out.print("--------");
        }
        System.out.println();
        for (int j = 0; j < 5; j++) {
            int sumaColumna = 0;
            for (int i = 0; i < 4; i++) {
                sumaColumna += numeros[i][j];
            }
            System.out.print(sumaColumna + "\t");
        }
        System.out.println("| " + sumaTotal);
    }
}  