/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg7ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Scanner teclado = new Scanner(System.in);
    
    int x1;
    int x2;
    int y1;
    int y2;
    int r1;
    int r2;
    double distancia;

   
    System.out.print("Escriba el valor \"x\" de la primera circunferencia: ");
    x1 = teclado.nextInt();
    System.out.print("Escriba el valor \"y\" de la primera circunferencia: ");
    y1 = teclado.nextInt();
    System.out.print("Escriba el radio de la primera circunferencia: ");
    r1 = teclado.nextInt();
    System.out.print("Escriba el valor \"x\" de la segunda circunferencia: ");
    x2 = teclado.nextInt();
    System.out.print("Escriba el valor \"y\" de la segunda circunferencia: ");
    y2 = teclado.nextInt();
    System.out.print("Escriba el radio de la segunda circunferencia: ");
    r2 = teclado.nextInt();
    

    distancia = Math.sqrt(Math.pow((x2-x1),2)+Math.pow((y2-y1),2));
  
    if (distancia == 0) {
      System.out.println("CONCENTRICAS.");
    } else if (distancia > (r1+r2)) {
      System.out.println("EXTERIORES.");
    } else if ((distancia > 0) && distancia < Math.abs(r1-r2)) {
      System.out.println("INTERIORES.");
    } else if (distancia == (r1+r2)) {
      System.out.println("TANGENTES EXTERIORES.");
    } else if (distancia == Math.abs(r1-r2)) {
      System.out.println("TANGENTES INTERIORES.");
    } else if (distancia < (r1+r2) && distancia > Math.abs(r1-r2)) {
      System.out.println("SECANTES.");
    }
    }
    
}
