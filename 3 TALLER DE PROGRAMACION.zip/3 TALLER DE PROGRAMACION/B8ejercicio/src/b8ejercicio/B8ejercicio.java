/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b8ejercicio;

/**
 *
 * @author Maria jose
 */


public class B8ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int horas = 0, minutos = 0, segundos = 0;
        
        while (true) {
            System.out.printf("%02d:%02d:%02d%n", horas, minutos, segundos);
            try {
                Thread.sleep(1000); 
                
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            
            segundos++;
            
            if (segundos == 60) {
                segundos = 0;
                minutos++;
            }
            
            if (minutos == 60) {
                minutos = 0;
                horas++;
            }
        }
    }
}



