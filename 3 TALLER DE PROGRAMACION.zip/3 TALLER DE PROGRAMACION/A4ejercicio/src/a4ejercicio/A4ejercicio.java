/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package a4ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Random;
public class A4ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    int[][] numeros = new int[4][5];
    Random rnd = new Random();

     
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                numeros[i][j] = rnd.nextInt(900) + 100; 
            }
        }

        
        int sumaTotal = 0;
        for (int i = 0; i < 4; i++) {
            int sumaFila = 0;
            for (int j = 0; j < 5; j++) {
                System.out.print(numeros[i][j] + "\t");
                sumaFila += numeros[i][j];
                sumaTotal += numeros[i][j];
            }
            System.out.println("| " + sumaFila);
        }
        for (int j = 0; j < 5; j++) {
            System.out.print("--------");
        }
        System.out.println();
        for (int j = 0; j < 5; j++) {
            int sumaColumna = 0;
            for (int i = 0; i < 4; i++) {
                sumaColumna += numeros[i][j];
            }
            System.out.print(sumaColumna + "\t");
        }
        System.out.println("| " + sumaTotal);
    }
}






    
    
