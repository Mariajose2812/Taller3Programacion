/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package a2ejercicios;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class A2ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    
        Scanner teclado = new Scanner(System.in);
        
        int i;
        int[] numero = new int[10];
        int maximo = Integer.MIN_VALUE;
        int minimo = Integer.MAX_VALUE;
        
       
        for (i=0;i<10;i++) {
            System.out.print("Escribe el numero "+(i+1)+": ");
            numero[i] = teclado.nextInt();
            if (numero[i]<minimo) {
                minimo  = numero[i];
            }
            if (numero[i]>maximo) {
                maximo = numero[i];
            }
        }
        for (i=0; i<10;i++) {
            if (numero[i]==maximo) {
                System.out.println("Numero "+ (i+1)+": "+numero[i] + " maximo.");
                }
            if (numero[i]== minimo) {
                System.out.println("Numero "+ (i+1)+": "+numero[i] + " minimo.");
            }
            if (numero[i] == maximo || numero[i] == minimo) {
            } else {
                System.out.println("Numero "+ (i+1)+": "+numero[i]);
            }
    }
    }
}
    

