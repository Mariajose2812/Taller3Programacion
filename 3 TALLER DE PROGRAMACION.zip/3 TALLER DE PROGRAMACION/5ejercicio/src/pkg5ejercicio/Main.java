/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg5ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      Scanner scanner = new Scanner(System.in);
    int base;
    int exponente;

   
    System.out.print("ESCRIBA LA BASE DE LA POTENCIA: ");
    base = scanner.nextInt();
    System.out.print("ESCRIBE EL EXPONENTE DE LA POTENCIA:");
    exponente = scanner.nextInt();
    

    if (base >= 1) {
      System.out.println("EL RESULTADO ES " + (Math.pow(base, exponente)));
    }else if (exponente == 0) {
       System.out.println("EL RESULTA ES 1.");
    }else {
        System.out.println("EL RESULTADO ES " + (Math.pow(base, 1/exponente)));
    }
    }
    
}
