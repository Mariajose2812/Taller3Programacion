/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b5ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B5ejercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner(System.in);
    
         
        int numero, suma = 0, dentro = 0, fuera = 0;
        boolean igualLimite = false, limiteCorrecto = false;

        System.out.print("Digite el limite inferior:");
        int limiteI = teclado.nextInt();

        System.out.print("Digite el limite Superior:");
        int limiteS = teclado.nextInt();

        if (limiteI >= limiteS) {

            System.out.println("¡VUELVE A INGRESAR LOS LIMITES, el inferior debe ser menor que el superior!!!!");

            System.out.print("Digite el limite inferior:");
            limiteI = teclado.nextInt();

            System.out.print("Digite el limite Superior:");
            limiteS = teclado.nextInt();

        }
        do {
            System.out.print("Introduce un número (0 para terminar):");
            numero = teclado.nextInt();
            if (numero == limiteI || numero == limiteS) {
                igualLimite = true;
            }
            if (numero > limiteI && numero < limiteS) {
                suma += numero;
                dentro++;
            } else {
                fuera++;
            }
        } while (numero != 0);

        System.out.println("La suma de los números dentro del intervalo es: " + suma);
        System.out.println("Hay " + dentro + " números dentro del intervalo.");
        System.out.println("Hay " + fuera + " números fuera del intervalo.");
        if (igualLimite) {
            System.out.println("Se ha introducido al menos un número igual a los límites del intervalo.");
        }

    }
}