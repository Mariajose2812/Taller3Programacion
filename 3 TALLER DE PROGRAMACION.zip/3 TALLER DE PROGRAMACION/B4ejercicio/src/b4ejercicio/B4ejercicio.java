/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b4ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B4ejercicio {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
     
    Scanner teclado = new Scanner(System.in);
    
    int numero1;
    int numero2;
    int minimo;
    int maximo;
    
 
    System.out.print("ESCRIBA EL PRIMER NUMERO: ");
    numero1 = teclado.nextInt();
    System.out.print("ESCRIBA EL SEGUNDO NUMERO:");
    numero2 = teclado.nextInt();
    
   
    if (numero1 < numero2) {
      minimo = numero1;
      maximo = numero2;
    } else {
      minimo = numero2;
      maximo = numero1;
    }

    for (int i=minimo+1; i < maximo; i++){
      if (i%2==0){
        System.out.println(i); 
      }
    }
  }
}
    
    

