/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b9ejercicios;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class B9ejercicios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    Scanner teclado = new Scanner(System.in);
    
    int numPrimos;
    int contador;
    boolean esPrimo;
    int divisor;
    int num;

      System.out.print("CUANTOS NUMEROS PRIMOS DESEA CONOCER: ");
      numPrimos = teclado.nextInt();

    System.out.println("1: 2");
    contador = 1;
    num = 3;
    
    while (contador < numPrimos){
      esPrimo = true;
      divisor=3;
      while ((divisor<=Math.sqrt((num))) && esPrimo) {
        if (num%divisor==0) {
          esPrimo = false;
        }
        divisor +=2;
      }
      if (esPrimo){
        contador +=1;
        System.out.println(contador + ": " + num);
      }
      num +=2;
    }
    
}
}
