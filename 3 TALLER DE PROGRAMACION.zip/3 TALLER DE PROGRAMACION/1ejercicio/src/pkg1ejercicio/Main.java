/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg1ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner (System.in);
    
    int numero1;
    int numero2;

    
    System.out.print("ESCRIBA EL PRIMER NUMERO: ");
    numero1 = teclado.nextInt();
    System.out.print("ESCRIBA EL SEGUNDO NUMERO: ");
    numero2 = teclado.nextInt();
    

    if (numero1 > numero2){
        System.out.println("EL PRIMER NUMERO: " +numero1 + " ES MAYOT QUE EL SEGUNDO NUMERO:" +numero2);
        
        
    }else if (numero1 < numero2){
        System.out.println("EL SEGUNDO NUMERO: " +numero2 + " ES MAYOR QUE EL PRIMER NUMERO: " +numero1);
        
    }else {
        System.out.println("EN ESTE CASO LOS DOS NUMEROS SON IGUALES: " +numero1);
    }    
    }
    
}
